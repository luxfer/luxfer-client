#!/bin/bash

(cd $(dirname $0) && java -jar LuxferClient.jar)

